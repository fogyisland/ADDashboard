CREATE TABLE metrics (
  agent_id   VARCHAR(64) NOT NULL,
  ts         DATETIME    NOT NULL,
  cpu_pct    DOUBLE NULL,
  memory_pct DOUBLE NULL
);