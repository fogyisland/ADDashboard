$cpu = (Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples.CookedValue
$mem = (Get-CimInstance Win32_OperatingSystem)
$pct = [math]::Round(($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) / $mem.TotalVisibleMemorySize * 100, 2)
@{ metrics = @{ cpu_pct = $cpu; memory_pct = $pct } } | ConvertTo-Json -Compress